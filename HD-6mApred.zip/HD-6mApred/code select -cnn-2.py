import numpy as np
import random
import os
import tensorflow as tf
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Conv1D, MaxPooling1D, Dropout, Flatten, Dense
from tensorflow.keras.optimizers import Adam
from sklearn.model_selection import train_test_split, KFold
from sklearn.metrics import accuracy_score, roc_auc_score, roc_curve
import matplotlib.pyplot as plt
import pandas as pd

# 设置随机种子, 确保结果可重复
def set_seeds(seed=42):
    os.environ['PYTHONHASHSEED'] = str(seed)
    random.seed(seed)
    np.random.seed(seed)
    tf.random.set_seed(seed)

# 数据读取函数
def read_seq(filepath):
    seq = []
    lst1 = []
    for line in open(filepath, 'r', encoding='utf-8'):
        line = line.strip()
        lst1.append(line)
    for i in range(len(lst1)):
        if i % 2 != 0:
            seq.append(lst1[i])
    return seq

# One-hot编码
def Onehot(seq):
    result = []
    for s in seq:
        lst = []
        for i in range(len(s)):
            if s[i] == 'A':
                lst.extend([1, 0, 0, 0])
            if s[i] == 'G':
                lst.extend([0, 0, 1, 0])
            if s[i] == 'C':
                lst.extend([0, 1, 0, 0])
            if s[i] == 'T':
                lst.extend([0, 0, 0, 1])
            if s[i] == 'N':
                lst.extend([0, 0, 0, 0])
        result.append(lst)
    return np.array(result)

# EIIP编码
def EIIP(seq):
    result = []
    for s in seq:
        lst = []
        for i in range(len(s)):
            if s[i] == 'A':
                lst.extend([0.1260])
            elif s[i] == 'C':
                lst.extend([0.1340])
            elif s[i] == 'G':
                lst.extend([0.0806])
            elif s[i] == 'T':
                lst.extend([0.1335])
            elif s[i] == 'N':
                lst.extend([0])
        result.append(lst)
    return np.array(result)

# NCP编码
def NCP(seq):
    result = []
    for s in seq:
        lst = []
        for i in range(len(s)):
            if s[i] == 'A':
                lst.extend([1, 1, 1])
            elif s[i] == 'C':
                lst.extend([0, 1, 0])
            elif s[i] == 'G':
                lst.extend([1, 0, 0])
            elif s[i] == 'T':
                lst.extend([0, 0, 1])
            else:
                lst.extend([0, 0, 0])
        result.append(lst)
    return np.array(result)

# ENAC编码
def ENAC(seq, k):
    result = []
    for s in seq:
        ENAC = []
        for i in range(len(s) - k + 1):
            a = s[i:i + k]
            A_fre = a.count('A') / k
            C_fre = a.count('C') / k
            G_fre = a.count('G') / k
            T_fre = a.count('T') / k
            ENAC.extend([A_fre, C_fre, G_fre, T_fre])
        result.append(ENAC)
    return np.array(result)

# 创建CNN模型
def create_model(input_shape):
    model = Sequential()
    model.add(Conv1D(128, kernel_size=3, activation='relu', input_shape=input_shape))
    model.add(MaxPooling1D(pool_size=2))
    model.add(Conv1D(128, kernel_size=3, activation='relu'))
    model.add(MaxPooling1D(pool_size=2))
    model.add(Flatten())
    model.add(Dropout(0.5))
    model.add(Dense(1, activation='sigmoid'))
    model.compile(optimizer=Adam(learning_rate=0.0001), loss='binary_crossentropy', metrics=['accuracy'])
    return model

def NCP_ENAC(pos_filepath, neg_filepath, k=5):
    pos_seq = read_seq(pos_filepath)
    neg_seq = read_seq(neg_filepath)
    pos_feature = np.concatenate([NCP(pos_seq), ENAC(pos_seq, k)], axis=1)
    neg_feature = np.concatenate([NCP(neg_seq), ENAC(neg_seq, k)], axis=1)
    label = np.concatenate([np.ones((len(pos_seq),)), np.zeros((len(neg_seq),))], axis=0)
    return np.concatenate([pos_feature, neg_feature], axis=0), label

def NCP_Onehot(pos_filepath, neg_filepath):
    pos_seq = read_seq(pos_filepath)
    neg_seq = read_seq(neg_filepath)
    pos_feature = np.concatenate([NCP(pos_seq), Onehot(pos_seq)], axis=1)
    neg_feature = np.concatenate([NCP(neg_seq), Onehot(neg_seq)], axis=1)
    label = np.concatenate([np.ones((len(pos_seq),)), np.zeros((len(neg_seq),))], axis=0)
    return np.concatenate([pos_feature, neg_feature], axis=0), label

def NCP_EIIP(pos_filepath, neg_filepath):
    pos_seq = read_seq(pos_filepath)
    neg_seq = read_seq(neg_filepath)
    pos_feature = np.concatenate([NCP(pos_seq), EIIP(pos_seq)], axis=1)
    neg_feature = np.concatenate([NCP(neg_seq), EIIP(neg_seq)], axis=1)
    label = np.concatenate([np.ones((len(pos_seq),)), np.zeros((len(neg_seq),))], axis=0)
    return np.concatenate([pos_feature, neg_feature], axis=0), label

# 编码序列和标签
def encode_sequences_and_labels(pos_filepath, neg_filepath, encoding_function, k=5):
    if encoding_function == NCP_ENAC:
        X, y = encoding_function(pos_filepath, neg_filepath, k)
    else:
        X, y = encoding_function(pos_filepath, neg_filepath)
    return X, y

# 处理数据并评估模型
def process_and_evaluate(pos_filepath, neg_filepath, encoding_function, encoding_name, k=5):
    set_seeds()  # 重置随机种子
    X, y = encode_sequences_and_labels(pos_filepath, neg_filepath, encoding_function, k)
    # 划分训练集和测试集（8:2）
    X_train_val, X_test, y_train_val, y_test = train_test_split(X, y, test_size=0.2, random_state=15)

    kf = KFold(n_splits=5, shuffle=True, random_state=15)

    acc_scores = []
    auc_scores = []
    tprs = []
    mean_fpr = np.linspace(0, 1, 100)

    plt.figure(figsize=(10, 8))

    for fold, (train_index, val_index) in enumerate(kf.split(X_train_val)):
        X_train, X_val = X_train_val[train_index], X_train_val[val_index]
        y_train, y_val = y_train_val[train_index], y_train_val[val_index]

        input_shape = (X_train.shape[1], 1)
        X_train = X_train.reshape((-1, input_shape[0], input_shape[1]))
        X_val = X_val.reshape((-1, input_shape[0], input_shape[1]))

        model = create_model(input_shape)
        model.fit(X_train, y_train, epochs=100, batch_size=32, validation_data=(X_val, y_val), verbose=0)

        X_test_reshaped = X_test.reshape((-1, input_shape[0], input_shape[1]))
        y_pred = model.predict(X_test_reshaped)
        fpr, tpr, _ = roc_curve(y_test, y_pred)
        tprs.append(np.interp(mean_fpr, fpr, tpr))
        tprs[-1][0] = 0.0
        roc_auc = roc_auc_score(y_test, y_pred)
        auc_scores.append(roc_auc)
        plt.plot(fpr, tpr, lw=1, alpha=0.3, label=f'ROC fold {fold+1} (AUC = {roc_auc:.2f})')

    plt.plot([0, 1], [0, 1], linestyle='--', lw=2, color='r', label='Chance', alpha=.8)
    mean_tpr = np.mean(tprs, axis=0)
    mean_tpr[-1] = 1.0
    mean_auc = np.mean(auc_scores)
    std_auc = np.std(auc_scores)
    plt.plot(mean_fpr, mean_tpr, color='b', label=r'Mean ROC (AUC = %0.2f $\pm$ %0.2f)' % (mean_auc, std_auc), lw=2, alpha=.8)

    plt.xlim([-0.05, 1.05])
    plt.ylim([-0.05, 1.05])
    plt.xlabel('False Positive Rate')
    plt.ylabel('True Positive Rate')
    plt.title(f'Receiver Operating Characteristic (ROC) Curve - {encoding_name} Encoding')
    plt.legend(loc="lower right")
    plt.show()

    # 在测试集上评估最终模型
    X_test_reshaped = X_test.reshape((-1, input_shape[0], input_shape[1]))
    y_pred = model.predict(X_test_reshaped)
    test_acc = accuracy_score(y_test, y_pred.round())
    test_auc = roc_auc_score(y_test, y_pred)

    return test_acc, test_auc

# 文件路径
pos_train_filepath = '/data/coding/positive_training_dataset_for_Rosaceae.txt'
neg_train_filepath = '/data/coding/negative_training_dataset_for_Rosaceae.txt'

# 评估每种编码方法
encodings = {
    'NCP-Onehot': NCP_Onehot,
    'NCP-EIIP': NCP_EIIP,
    'NCP-ENAC': NCP_ENAC,  # 使用k=5的ENAC
}

results = {}

for name, encoding_function in encodings.items():
    print(f"Processing {name} encoding...")
    acc, auc = process_and_evaluate(pos_train_filepath, neg_train_filepath, encoding_function, name)
    results[name] = {'ACC': acc, 'AUC': auc}
    print(f"{name} - Test ACC: {acc:.4f}, Test AUC: {auc:.4f}")

# 绘制ACC比较柱形图
plt.figure(figsize=(10, 6))
names = list(results.keys())
acc_values = [results[name]['ACC'] for name in names]
plt.bar(names, acc_values)
plt.title('Comparison of ACC for Different Encodings')
plt.xlabel('Encoding Method')
plt.ylabel('ACC')
plt.ylim(0, 1)
for i, v in enumerate(acc_values):
    plt.text(i, v, f'{v:.4f}', ha='center', va='bottom')
plt.show()

# 打印结果表格
df_results = pd.DataFrame(results).T
print("\nResults Table:")
print(df_results)